public class Partition {
    Partition(){
        this.sz = sz;
        this.process_index = -1;
    }
    public int sz;
    public String name;
    int process_index;
}
