public class Process {
    Process(int sz,String name){
        this.sz = sz;
        this.name = name;
    }
    public int sz;
    public String name;
}
